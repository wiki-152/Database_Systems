﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Patient
{
    public string patientId { get; set; }
    public string name { get; set; }
    public int age { get; set; }
    public string gender { get; set; }
    public string medicalCondition { get; set; }

    public Patient() 
    {
        input();
    }

    public Patient(string input_patientId, string input_name, int input_age, string input_gender, string input_medicalCondition)
    {
        patientId = input_patientId;
        name = input_name;
        age = input_age;
        gender = input_gender;
        medicalCondition = input_medicalCondition;
    }

    public void input()
    {
        Console.Write("Enter Patient ID : ");
        patientId = Console.ReadLine();
        Console.Write("Enter Patient Name : ");
        name = Console.ReadLine();
        Console.Write("Enter Patient Age : ");
        age = Convert.ToInt32(Console.ReadLine());
        while (age < 0 || age > 130)
        {
            Console.Write("Invalid Input!! Enter Patient Age : ");
            age = Convert.ToInt32(Console.ReadLine());
        }
        Console.Write("Enter Patient Gender : ");
        gender = Console.ReadLine();
        while (gender != "Male" && gender != "Female")
        {
            Console.Write("Invalid Input!! Enter Patient Gender : ");
            gender = Console.ReadLine();
        }
        Console.Write("Enter Patient Medical Condition : ");
        medicalCondition = Console.ReadLine();
    }

}

class Doctor
{
    public string doctorId { get; set; }
    public string name { get; set; }
    public string specialization { get; set; }
    public bool availability { get; set; }

    public Doctor()
    {
        input();
    }

    public Doctor(string input_doctorId, string input_name, string input_specialization, bool input_availability)
    {
        doctorId = input_doctorId;
        name = input_name;
        specialization = input_specialization;
        availability = input_availability;
    }

    public void input()
    {
        Console.Write("Enter Doctor ID : ");
        doctorId = Console.ReadLine();
        Console.Write("Enter Doctor Name : ");
        name = Console.ReadLine();
        Console.Write("Enter Doctor Specialization : ");
        specialization = Console.ReadLine();
        Console.Write("Enter Doctor Availability : ");
        availability = Convert.ToBoolean(Console.ReadLine());
    }
}

class Appointment
{
    public string appointmentId { get; set; }
    public Patient patient { get; set; }
    public Doctor doctor { get; set; }
    public string date { get; set; }
    public string time { get; set; }
    public bool statusScheduled { get; set; }
    public bool statusRescheduled { get; set; }
    public bool statusCancelled { get; set; }

    public Appointment(List<Patient> patients, List<Doctor> doctors)
    {
        input(patients,doctors);
    }

    public Appointment(string input_appointmentId, Patient input_patient, Doctor input_doctor, string input_date, string input_time, bool input_statusScheduled, bool input_statusRescheduled, bool input_statusCancelled)
    {
        appointmentId = input_appointmentId;
        patient = input_patient;
        doctor = input_doctor;
        date = input_date;
        time = input_time;
        statusScheduled = input_statusScheduled;
        statusRescheduled = input_statusRescheduled;
        statusCancelled = input_statusCancelled;
    }

    public void input(List<Patient> patients, List<Doctor> doctors)
    {
        Console.Write("Enter Appointment ID : ");
        appointmentId = Console.ReadLine();

        for (int i = 0; i < patients.Count; i++)
        {
            Console.WriteLine("Patient ID : " + patients[i].patientId + " Patient Name : " + patients[i].name);
        }

        Console.Write("Enter Patient ID : ");
        string patientId = Console.ReadLine();

        bool exists = false;
        for (int i = 0; i < patients.Count; i++)
        {
            if (patients[i].patientId == patientId)
            {
                patient = patients[i];
                exists = true;
            }
        }

        while (exists == false)
        {
            Console.WriteLine("Patient Not Found");
            Console.Write("Enter Patient ID : ");
            patientId = Console.ReadLine();
            for (int i = 0; i < patients.Count; i++)
            {
                if (patients[i].patientId == patientId)
                {
                    patient = patients[i];
                    exists = true;
                }
            }
        }

        exists = false;




        for (int i = 0; i < doctors.Count; i++)
        {
            Console.WriteLine("Doctor ID : " + doctors[i].doctorId + " Doctor Name : " + doctors[i].name);
        }

        Console.Write("Enter Doctor ID : ");
        string doctorId = Console.ReadLine();
        for (int i = 0; i < doctors.Count; i++)
        {
            if (doctors[i].doctorId == doctorId)
            {
                doctor = doctors[i];
                exists = true;
            }
        }

        while (exists == false || doctor.availability == false)
        {
            Console.WriteLine("Doctor Not Found or Not Available");
            Console.Write("Enter Doctor ID : ");
            doctorId = Console.ReadLine();

            for (int i = 0; i < doctors.Count; i++)
            {
                if (doctors[i].doctorId == doctorId)
                {
                    doctor = doctors[i];
                    exists = true;
                }
            }

            if (doctor.availability == false)
            {
                Console.WriteLine("Doctor Not Available");
                Console.Write("Enter Doctor ID : ");
                doctorId = Console.ReadLine();
                for (int i = 0; i < doctors.Count; i++)
                {
                    if (doctors[i].doctorId == doctorId)
                    {
                        doctor = doctors[i];
                        exists = true;
                    }
                }
            }
        }

        exists = false;



        Console.Write("Enter Appointment Date : ");
        date = Console.ReadLine();
        Console.Write("Enter Appointment Time : ");
        time = Console.ReadLine();
        Console.Write("Enter Appointment Status (Scheduled) : ");
        statusScheduled = Convert.ToBoolean(Console.ReadLine());
        Console.Write("Enter Appointment Status (Rescheduled) : ");
        statusRescheduled = Convert.ToBoolean(Console.ReadLine());
        Console.Write("Enter Appointment Status (Cancelled) : ");
        statusCancelled = Convert.ToBoolean(Console.ReadLine());
    }

}

namespace i222469_E_LabTask4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Patient> patients = new List<Patient>();
            List<Doctor> doctors = new List<Doctor>();
            List<Appointment> appointments = new List<Appointment>(); 

            Patient patient1 = new Patient("P1", "Ali", 20, "Male", "Flu");

            Doctor doctor1 = new Doctor("D1", "Dr. Aslam", "General Physician", true);

            Appointment a1 = new Appointment("A1", patient1, doctor1, "13/02/2024", "10:00 AM", false, false, false);

            patients.Add(patient1);
            doctors.Add(doctor1);
            appointments.Add(a1);

            int input_Choice = -1;
            while (input_Choice != 0)
            {
                Console.WriteLine("---------------------------------MENU------------------------------");
                Console.WriteLine();
                Console.WriteLine("1. Add Patient");
                Console.WriteLine("2. Add Doctor");
                Console.WriteLine("3. Add Appointment");
                Console.WriteLine("4. Show All Patients");
                Console.WriteLine("5. Show All Doctors");
                Console.WriteLine("6. Show All Appointments");
                Console.WriteLine("7. Delete Patient");
                Console.WriteLine("8. Delete Doctor");
                Console.WriteLine("9. Delete Appointment");
                Console.WriteLine("10. Reschedule Appointment");
                Console.WriteLine("11. View Appointments By Date");
                Console.WriteLine("12. View Appointments By Doctor");
                Console.WriteLine("13. View Appointments By Patient");
                Console.WriteLine("0. Exit");

                Console.Write("Enter Choice : ");
                input_Choice = Convert.ToInt32(Console.ReadLine());

                while (input_Choice < 0 || input_Choice > 13)
                {
                    Console.WriteLine("Invalid Choice");
                    Console.Write("Enter Choice : ");
                    input_Choice = Convert.ToInt32(Console.ReadLine());
                }

                Console.WriteLine();
                Console.WriteLine();

                switch (input_Choice)
                {
                    case 1:

                        Patient patient2 = new Patient();

                        bool exists = false;

                        for (int i = 0; i < patients.Count; i++)
                        {
                            if (patients[i].patientId == patient2.patientId)
                            {
                                exists = true;
                            }
                        }

                        if (exists == false)
                        {
                            patients.Add(patient2);
                        }
                        else
                        {
                            Console.WriteLine("Patient Already Exists");
                            exists = false;
                        }


                        break;
                    case 2:

                        Doctor doctor2 = new Doctor();

                        bool exists2 = false;

                        for (int i = 0; i < doctors.Count; i++)
                        {
                            if (doctors[i].doctorId == doctor2.doctorId)
                            {
                                exists2 = true;
                            }
                        }

                        if (exists2 == false)
                        {
                            doctors.Add(doctor2);
                        }
                        else
                        {
                            Console.WriteLine("Doctor Already Exists");
                            exists2 = false;
                        }

                        break;
                    case 3:

                        Appointment a2 = new Appointment(patients , doctors);

                        bool exists3 = false;

                        for (int i = 0; i < appointments.Count; i++)
                        {
                            if (appointments[i].appointmentId == a2.appointmentId)
                            {
                                exists3 = true;
                            }
                        }

                        if (exists3 == false)
                        {
                            appointments.Add(a2);
                        }
                        else
                        {
                            Console.WriteLine("Appointment Already Exists");
                            exists3 = false;
                        }

                        break;
                    case 4:
                        
                        for (int i = 0; i < patients.Count; i++)
                        {
                            Console.WriteLine("Patient ID : " + patients[i].patientId + " Patient Name : " + patients[i].name + " Patient Age : " + patients[i]);
                        }

                        break;
                    case 5:

                        for (int i = 0; i < doctors.Count; i++)
                        {
                            Console.WriteLine("Doctor ID : " + doctors[i].doctorId + " Doctor Name : " + doctors[i].name + " Doctor Specialization : " + doctors[i].specialization + " Doctor Availability : " + doctors[i].availability);
                        }

                        break;
                    case 6:

                        for (int i = 0; i < appointments.Count; i++)
                        {
                            Console.WriteLine("Appointment ID : " + appointments[i].appointmentId + " Patient ID : " + appointments[i].patient.patientId + " Doctor ID : " + appointments[i].doctor.doctorId + " Date : " + appointments[i].date + " Time : " + appointments[i].time + " Status (Scheduled) : " + appointments[i].statusScheduled + " Status (Rescheduled) : " + appointments[i].statusRescheduled + " Status (Cancelled) : " + appointments[i].statusCancelled);
                        }

                        break;
                    case 7:

                        bool deleted = false;

                        for (int i = 0; i < patients.Count; i++)
                        {
                            Console.WriteLine("Patient ID : " + patients[i].patientId + " Patient Name : " + patients[i].name);
                        }

                        Console.Write("Enter Patient ID to Delete : ");
                        string patientId = Console.ReadLine();
                        for (int i = 0; i < patients.Count; i++)
                        {
                            if (patients[i].patientId == patientId)
                            {
                                patients.RemoveAt(i);
                                deleted = true;
                            }
                        }

                        if (deleted == false)
                        {
                            Console.WriteLine("Patient Not Found");
                        }
                        else
                        {
                            Console.WriteLine("Patient Deleted!");
                        }

                        break;
                    case 8:

                        bool deleted2 = false;

                        for (int i = 0; i < doctors.Count; i++)
                        {
                            Console.WriteLine("Doctor ID : " + doctors[i].doctorId + " Doctor Name : " + doctors[i].name);
                        }

                        Console.Write("Enter Doctor ID to Delete : ");
                        string doctorId = Console.ReadLine();

                        for (int i = 0; i < doctors.Count; i++)
                        {
                            if (doctors[i].doctorId == doctorId)
                            {
                                doctors.RemoveAt(i);
                                deleted = true;
                            }
                        }

                        if (deleted2 == false)
                        {
                            Console.WriteLine("Doctor Not Found");
                        }
                        else
                        {
                            Console.WriteLine("Doctor Deleted!");
                        }

                        break;
                    case 9:

                        bool deleted3 = false;

                        for (int i = 0; i < appointments.Count; i++)
                        {
                            Console.WriteLine("Appointment ID : " + appointments[i].appointmentId + " Patient ID : " + appointments[i].patient.patientId + " Doctor ID : " + appointments[i].doctor.doctorId + " Date : " + appointments[i].date + " Time : " + appointments[i].time + " Status (Scheduled) : " + appointments[i].statusScheduled + " Status (Rescheduled) : " + appointments[i].statusRescheduled + " Status (Cancelled) : " + appointments[i].statusCancelled);
                        }

                        Console.Write("Enter Appointment ID to Delete : ");
                        string appointmentId = Console.ReadLine();

                        for (int i = 0; i < appointments.Count; i++)
                        {
                            if (appointments[i].appointmentId == appointmentId)
                            {
                                appointments.RemoveAt(i);
                                deleted = true;
                            }
                        }

                        if (deleted3 == false)
                        {
                            Console.WriteLine("Appointment Not Found");
                        }
                        else
                        {
                            Console.WriteLine("Appointment Deleted!");
                        }

                        break;
                    case 10:

                        Console.Write("Enter Appointment ID to Reschedule : ");
                        string appointmentId2 = Console.ReadLine();

                        bool exists4 = false;

                        for (int i = 0; i < appointments.Count; i++)
                        {
                            if (appointments[i].appointmentId == appointmentId2)
                            {
                                exists4 = true;
                                Console.Write("Enter New Date : ");
                                appointments[i].date = Console.ReadLine();
                                Console.Write("Enter New Time : ");
                                appointments[i].time = Console.ReadLine();
                                appointments[i].statusRescheduled = true;
                            }
                        }

                        if (exists4 == false)
                        {
                            Console.WriteLine("Appointment Not Found");
                        }
                        else
                        {
                            Console.WriteLine("Appointment Rescheduled!");
                            exists4 = false;
                        }

                        break;
                    case 11:

                        Console.Write("Enter Date to View Appointments : ");
                        string date = Console.ReadLine();
                        bool exists5 = false;
                        for (int i = 0; i < appointments.Count; i++)
                        {
                            if (appointments[i].date == date)
                            {
                                exists5 = true;
                                Console.WriteLine("Appointment ID : " + appointments[i].appointmentId + " Patient ID : " + appointments[i].patient.patientId + " Doctor ID : " + appointments[i].doctor.doctorId + " Date : " + appointments[i].date + " Time : " + appointments[i].time + " Status (Scheduled) : " + appointments[i].statusScheduled + " Status (Rescheduled) : " + appointments[i].statusRescheduled + " Status (Cancelled) : " + appointments[i].statusCancelled);
                            }
                        }

                        if (exists5 == false)
                        {
                            Console.WriteLine("No Appointments Found");
                        }
                        else
                        {
                            exists5 = false;
                        }

                        break;
                    case 12:

                        Console.Write("Enter Doctor ID to View Appointments : ");
                        string doctorId2 = Console.ReadLine();

                        bool exists6 = false;

                        for (int i = 0; i < appointments.Count; i++)
                        {
                            if (appointments[i].doctor.doctorId == doctorId2)
                            {
                                exists6 = true;
                                Console.WriteLine("Appointment ID : " + appointments[i].appointmentId + " Patient ID : " + appointments[i].patient.patientId + " Doctor ID : " + appointments[i].doctor.doctorId + " Date : " + appointments[i].date + " Time : " + appointments[i].time + " Status (Scheduled) : " + appointments[i].statusScheduled + " Status (Rescheduled) : " + appointments[i].statusRescheduled + " Status (Cancelled) : " + appointments[i].statusCancelled);
                            }
                        }
                        
                        if (exists6 == false)
                        {
                            Console.WriteLine("No Appointments Found");
                        }
                        else
                        {
                            exists6 = false;
                        }

                        break;
                    case 13:

                        Console.Write("Enter Patient ID to View Appointments : ");

                        string patientId2 = Console.ReadLine();

                        bool exists7 = false;

                        for (int i = 0; i < appointments.Count; i++)
                        {
                            if (appointments[i].patient.patientId == patientId2)
                            {
                                exists7 = true;
                                Console.WriteLine("Appointment ID : " + appointments[i].appointmentId + " Patient ID : " + appointments[i].patient.patientId + " Doctor ID : " + appointments[i].doctor.doctorId + " Date : " + appointments[i].date + " Time : " + appointments[i].time + " Status (Scheduled) : " + appointments[i].statusScheduled + " Status (Rescheduled) : " + appointments[i].statusRescheduled + " Status (Cancelled) : " + appointments[i].statusCancelled);
                            }
                        }

                        if (exists7 == false)
                        {
                            Console.WriteLine("No Appointments Found");
                        }
                        else
                        {
                            exists7 = false;
                        }

                        break;
                    default:
                        Console.WriteLine("Closing Application...");
                        break;
                }
            }



        }
    }
}
