using Microsoft.Data.SqlClient;
using System.Data;
namespace testing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void last_name_Click(object sender, EventArgs e)
        {

        }

        private void Save_btn_Click(object sender, EventArgs e)
        {
            string firstName = fname.Text;
            string lastName = lname.Text;

            // Check if the first name is empty
            if (string.IsNullOrWhiteSpace(firstName))
            {
                lblout.Text = "Please enter a first name.";
                return;
            }

            // Check if the last name is empty
            if (string.IsNullOrWhiteSpace(lastName))
            {
                lblout.Text = "Please enter a last name.";
                return;
            }

            // Your connection string
            string cnstring = "Data Source=LAB_WORK\\SQLEXPRESS;Initial Catalog=task; Integrated Security=True; Encrypt=false";

            // Your SQL query
            string sqlquery = "INSERT INTO temp (first_name, last_name) VALUES (@FirstName, @LastName)";

            try
            {
                // Create a connection
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();

                    // Create a command with the SQL query and the connection
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        // Add parameters to the command
                        cm.Parameters.AddWithValue("@FirstName", firstName);
                        cm.Parameters.AddWithValue("@LastName", lastName);

                        // Execute the query
                        cm.ExecuteNonQuery();
                    }
                }

                lblout.Text = "Record inserted successfully.";
            }
            catch (Exception ex)
            {
                lblout.Text = "Error: " + ex.Message;
            }


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cnstring = "Data Source = LAB_WORK\\SQLEXPRESS; Initial Catalog=task; Integrated Security = True; Encrypt=false";
            SqlConnection con = new SqlConnection(cnstring);
            con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM temp", con);

            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;



        }

        private void fname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
