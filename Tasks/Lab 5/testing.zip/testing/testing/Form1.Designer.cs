﻿namespace testing
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            fname = new TextBox();
            lname = new TextBox();
            first_name = new Label();
            last_name = new Label();
            Save_btn = new Button();
            lblout = new Label();
            dataGridView1 = new DataGridView();
            button1 = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // fname
            // 
            fname.Location = new Point(220, 120);
            fname.Name = "fname";
            fname.Size = new Size(362, 27);
            fname.TabIndex = 0;
            fname.TextChanged += fname_TextChanged;
            // 
            // lname
            // 
            lname.Location = new Point(220, 169);
            lname.Name = "lname";
            lname.Size = new Size(362, 27);
            lname.TabIndex = 1;
            // 
            // first_name
            // 
            first_name.AutoSize = true;
            first_name.Location = new Point(104, 117);
            first_name.Name = "first_name";
            first_name.Size = new Size(80, 20);
            first_name.TabIndex = 2;
            first_name.Text = "First Name";
            // 
            // last_name
            // 
            last_name.AutoSize = true;
            last_name.Location = new Point(104, 172);
            last_name.Name = "last_name";
            last_name.Size = new Size(76, 20);
            last_name.TabIndex = 3;
            last_name.Text = "Last name";
            last_name.Click += last_name_Click;
            // 
            // Save_btn
            // 
            Save_btn.Location = new Point(540, 304);
            Save_btn.Name = "Save_btn";
            Save_btn.Size = new Size(94, 29);
            Save_btn.TabIndex = 4;
            Save_btn.Text = "Save";
            Save_btn.UseVisualStyleBackColor = true;
            Save_btn.Click += Save_btn_Click;
            // 
            // lblout
            // 
            lblout.AutoSize = true;
            lblout.Location = new Point(564, 221);
            lblout.Name = "lblout";
            lblout.Size = new Size(0, 20);
            lblout.TabIndex = 5;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(24, 221);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(454, 211);
            dataGridView1.TabIndex = 6;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // button1
            // 
            button1.Location = new Point(654, 304);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 7;
            button1.Text = "Show";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ActiveCaption;
            label1.Font = new Font("Segoe UI Variable Display", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(319, 34);
            label1.Name = "label1";
            label1.Size = new Size(228, 58);
            label1.TabIndex = 8;
            label1.Text = "Welcome ";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.IndianRed;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Controls.Add(lblout);
            Controls.Add(Save_btn);
            Controls.Add(last_name);
            Controls.Add(first_name);
            Controls.Add(lname);
            Controls.Add(fname);
            ForeColor = SystemColors.ActiveCaptionText;
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox fname;
        private TextBox lname;
        private Label first_name;
        private Label last_name;
        private Button Save_btn;
        private Label lblout;
        private DataGridView dataGridView1;
        private Button button1;
        private Label label1;
    }
}
