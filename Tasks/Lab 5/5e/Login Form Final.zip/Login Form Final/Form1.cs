using Microsoft.Data.SqlClient;


namespace Login_Form_Final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void login_button_Click(object sender, EventArgs e)
        {

            //int i = 0;
            //while (i<=10)
            //{
            //    i += 1;
            //    Task.Run(() => MessageBox.Show("Login Successful"));

            //}

            //if (textBox3.Text == "waqas_457" && textBox1.Text == "admin")
            //{
            //    MessageBox.Show("Login Successful");

            //}
            //else
            //{
            //    MessageBox.Show("Login Failed");
            //}


            string firstName = textBox3.Text;
            string lastName = textBox1.Text;

            if (string.IsNullOrEmpty(firstName))
            {
                MessageBox.Show("Please enter your first name");
                return;
            }

            if (string.IsNullOrEmpty(lastName))
            {
                MessageBox.Show("Please enter your last name");
                return;
            }

            if (string.IsNullOrEmpty(agebox.Text))
            {
                MessageBox.Show("Please enter your age");
                return;
            }

            if (string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Please enter your address");
                return;
            }



            string connectionString = "Data Source=WIKI\\SQLEXPRESS;Initial Catalog=Person; Integrated Security=True; Encrypt=false";
            // Query to execute

            string query = "INSERT INTO person_info (first_name,last_name,age,address) VALUES (@FirstName , @LastName, @age ,@address);";

            // Create a connection to the database
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Open the connection
                    connection.Open();

                    // Create a command and execute the query
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@FirstName", firstName);
                        command.Parameters.AddWithValue("@LastName", lastName);
                        command.Parameters.AddWithValue("@age", agebox.Text);
                        command.Parameters.AddWithValue("@address", textBox2.Text);

                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Data has been saved successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }

        }

        private void cancel_button_Click(object sender, EventArgs e)
        {
            textBox3.Text = "";
            textBox1.Text = "";
            agebox.Text = "";
            textBox2.Text = "";
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
