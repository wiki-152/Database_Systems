﻿namespace Login_Form_Final
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBox3 = new TextBox();
            textBox1 = new TextBox();
            login_button = new Button();
            cancel_button = new Button();
            printDialog1 = new PrintDialog();
            agebox = new TextBox();
            label5 = new Label();
            textBox2 = new TextBox();
            label4 = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Showcard Gothic", 34.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ImageAlign = ContentAlignment.TopCenter;
            label1.Location = new Point(243, 28);
            label1.Name = "label1";
            label1.RightToLeft = RightToLeft.No;
            label1.Size = new Size(379, 71);
            label1.TabIndex = 0;
            label1.Text = "Login Form";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(75, 139);
            label2.Name = "label2";
            label2.Size = new Size(101, 23);
            label2.TabIndex = 2;
            label2.Text = "First Name :";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(438, 139);
            label3.Name = "label3";
            label3.Size = new Size(91, 23);
            label3.TabIndex = 3;
            label3.Text = "Last Name";
            label3.Click += label3_Click;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(75, 165);
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = "Waqas";
            textBox3.Size = new Size(259, 27);
            textBox3.TabIndex = 5;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(438, 165);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Khan";
            textBox1.Size = new Size(259, 27);
            textBox1.TabIndex = 6;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // login_button
            // 
            login_button.Location = new Point(299, 348);
            login_button.Name = "login_button";
            login_button.Size = new Size(94, 29);
            login_button.TabIndex = 8;
            login_button.Text = "Save";
            login_button.UseVisualStyleBackColor = true;
            login_button.Click += login_button_Click;
            // 
            // cancel_button
            // 
            cancel_button.Location = new Point(438, 348);
            cancel_button.Name = "cancel_button";
            cancel_button.Size = new Size(94, 29);
            cancel_button.TabIndex = 9;
            cancel_button.Text = "Clear";
            cancel_button.UseVisualStyleBackColor = true;
            cancel_button.Click += cancel_button_Click;
            // 
            // printDialog1
            // 
            printDialog1.UseEXDialog = true;
            // 
            // agebox
            // 
            agebox.Location = new Point(75, 249);
            agebox.Name = "agebox";
            agebox.PlaceholderText = "20";
            agebox.Size = new Size(259, 27);
            agebox.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(75, 223);
            label5.Name = "label5";
            label5.Size = new Size(44, 23);
            label5.TabIndex = 12;
            label5.Text = "Age:";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(438, 249);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "........Pakistan";
            textBox2.Size = new Size(259, 27);
            textBox2.TabIndex = 13;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(438, 223);
            label4.Name = "label4";
            label4.Size = new Size(70, 23);
            label4.TabIndex = 14;
            label4.Text = "Address";
            // 
            // button1
            // 
            button1.Location = new Point(366, 383);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 15;
            button1.Text = "Cancel";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ScrollBar;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(label4);
            Controls.Add(textBox2);
            Controls.Add(label5);
            Controls.Add(agebox);
            Controls.Add(cancel_button);
            Controls.Add(login_button);
            Controls.Add(textBox1);
            Controls.Add(textBox3);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textBox3;
        private TextBox textBox1;
        private Button login_button;
        private Button cancel_button;
        private PrintDialog printDialog1;
        private TextBox agebox;
        private Label label5;
        private TextBox textBox2;
        private Label label4;
        private Button button1;
    }
}
